﻿<!-- rodapé --->
<br><br>
<footer  class="footer fixed-bottom bg-light">
	
	<div class="text-center">
			<small>&copy;AbgSoluções -  <?=date("Y")?> - abgsolucoes.tec.br </small>
	</div>

</footer>
