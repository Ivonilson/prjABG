<?php
require "model/ValorAvaliacao.php";
//require "model/Cidade.php";

class crtValorAvaliacao {

	public function valorAvaliacao()
	{	
		include "view/valor-de-avaliacao.php";
	}
}

?>