<?php
require "model/ListaMamck.php";

class crtListaMamck {

	public function listaMamck()
	{	
		include "view/lista-mamck.php";
	}
}

?>