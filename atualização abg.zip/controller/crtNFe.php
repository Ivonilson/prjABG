<?php 
require "model/Nfe.php";

	class crtNFe {

		public function Nfe()
		{
			include "view/nfe.php";
		}

	}

?>