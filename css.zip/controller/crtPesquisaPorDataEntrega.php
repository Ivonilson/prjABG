<?php
require "model/PesquisaPorDataEntrega.php";

class crtPesquisaPorDataEntrega {

	public function PesquisaPorDataEntrega()
	{	
		include "view/pesquisa-por-data-entrega.php";
	}
}

?>