<?php
require "model/DemandasDoDia.php";

class crtDemandasDoDia {

	public function demandasDoDia()
		{
			include "view/demandas-do-dia.php";
		}
	}

?>