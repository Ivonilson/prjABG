<?php
require "model/HistoricoModelo.php";

class crtHistoricoModelo {

	public function historicoModelo()
	{	
		include "view/historico-modelo.php";
	}
}

?>