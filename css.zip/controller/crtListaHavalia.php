<?php
require "model/ListaHavalia.php";

class crtListaHavalia {

	public function listaHavalia()
	{	
		include "view/lista-havalia.php";
	}
}

?>